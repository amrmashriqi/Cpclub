from Houdini.HoudiniFactory import HoudiniFactory

server = HoudiniFactory(server="Wind")
server.start()